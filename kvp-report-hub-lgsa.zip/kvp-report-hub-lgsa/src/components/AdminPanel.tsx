import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Trash2, Archive, UserX, Megaphone, X, CheckCircle, Send, Plus, MessageCircle, Users } from "lucide-react";
import TutorialManager from './TutorialManager';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface Report {
  id: string;
  type: string;
  description: string;
  guest_name: string;
  screenshot_url: string | null;
  timestamp: string;
  admin_response: string | null;
  admin_response_timestamp: string | null;
  status: string | null;
}

interface PublicMessage {
  id: string;
  sender_name: string;
  message: string;
  timestamp: string;
}

interface PrivateMessage {
  id: string;
  sender_name: string;
  receiver_name: string;
  message: string;
  timestamp: string;
}

interface AdminMessage {
  id: string;
  guest_name: string;
  message: string;
  sender_type: string;
  timestamp: string;
}

interface Post {
  id: string;
  author_name: string;
  title: string;
  content: string;
  likes: number;
  timestamp: string;
}

interface UserSuggestion {
  username: string;
  last_seen: string;
}

interface AdminPanelProps { skipPassword?: boolean }

const AdminPanel: React.FC<AdminPanelProps> = ({ skipPassword }) => {
  const [reports, setReports] = useState<Report[]>([]);
  const [publicMessages, setPublicMessages] = useState<PublicMessage[]>([]);
  const [privateMessages, setPrivateMessages] = useState<PrivateMessage[]>([]);
  const [adminMessages, setAdminMessages] = useState<AdminMessage[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [userSuggestions, setUserSuggestions] = useState<UserSuggestion[]>([]);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [reportReplies, setReportReplies] = useState<AdminMessage[]>([]);
  const [adminResponse, setAdminResponse] = useState('');
  const [player1, setPlayer1] = useState('');
  const [player2, setPlayer2] = useState('');
  const [selectedGuest, setSelectedGuest] = useState('');
  const [newAdminMessage, setNewAdminMessage] = useState('');
  const [muteUsername, setMuteUsername] = useState('');
  const [muteReason, setMuteReason] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [announcementTitle, setAnnouncementTitle] = useState('');
  const [announcementContent, setAnnouncementContent] = useState('');
  const [announcementImage, setAnnouncementImage] = useState<File | null>(null);
  const [selectedTab, setSelectedTab] = useState('reports');
  const [adminPassword, setAdminPassword] = useState('');
  const [reportDialogOpen, setReportDialogOpen] = useState(false);
  const [inactiveUsers, setInactiveUsers] = useState<any[]>([]);
  const [deleteAccountUsername, setDeleteAccountUsername] = useState('');
  const [adminAccessUsername, setAdminAccessUsername] = useState('');
  const [adminAccessAction, setAdminAccessAction] = useState<'enable' | 'disable'>('enable');

  useEffect(() => {
    fetchAllData();
    fetchUserSuggestions();

    // Check admin password unless skipPassword
    const checkPassword = () => {
      if (skipPassword) return true;
      const password = prompt('Enter admin password:');
      if (password !== 'kvrplobby') {
        alert('Invalid password');
        return false;
      }
      return true;
    };

    if (!checkPassword()) return;

    // Subscribe to real-time updates for admin messages (user replies)
    const messagesChannel = supabase
      .channel('admin-messages-updates')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'admin_messages'
      }, (payload) => {
        console.log('Admin message update:', payload);
        if (payload.eventType === 'INSERT') {
          const newMessage = payload.new as AdminMessage;
          
          // Update the adminMessages state directly without calling fetchAllData
          setAdminMessages(prev => {
            // Avoid duplicates by checking if message already exists
            const exists = prev.find(msg => msg.id === newMessage.id);
            if (exists) return prev;
            return [...prev, newMessage];
          });
          
          // If we have a selected report for this user, update replies for both admin and user messages
          if (selectedReport && newMessage.guest_name === selectedReport.guest_name) {
            setReportReplies(prev => {
              const exists = prev.find(msg => msg.id === newMessage.id);
              if (exists) return prev;
              return [...prev, newMessage];
            });
            
            if (newMessage.sender_type === 'user') {
              toast.success(`New reply from ${newMessage.guest_name}`);
            }
          }
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(messagesChannel);
    };
  }, [selectedReport]);

  // Fetch replies for the selected report
  useEffect(() => {
    if (selectedReport) {
      fetchReportReplies(selectedReport.guest_name);
    } else {
      setReportReplies([]);
    }
  }, [selectedReport]);

  const fetchReportReplies = async (guestName: string) => {
    try {
      const { data, error } = await supabase
        .from('admin_messages')
        .select('*')
        .eq('guest_name', guestName)
        .order('timestamp', { ascending: true });

      if (error) {
        console.error('Error fetching report replies:', error);
        return;
      }

      setReportReplies(data || []);
    } catch (error) {
      console.error('Unexpected error fetching report replies:', error);
    }
  };

  const fetchUserSuggestions = async () => {
    try {
      // Get unique usernames from various tables to suggest friends
      const [publicChatUsers, privateChatUsers, reportsUsers] = await Promise.all([
        supabase.from('public_chat').select('sender_name').order('timestamp', { ascending: false }).limit(50),
        supabase.from('private_chats').select('sender_name, receiver_name').order('timestamp', { ascending: false }).limit(50),
        supabase.from('reports').select('guest_name').order('timestamp', { ascending: false }).limit(50)
      ]);

      const allUsers = new Set<string>();
      
      // Add users from public chat
      publicChatUsers.data?.forEach(user => {
        if (user.sender_name) {
          allUsers.add(user.sender_name);
        }
      });

      // Add users from private chats
      privateChatUsers.data?.forEach(chat => {
        if (chat.sender_name) {
          allUsers.add(chat.sender_name);
        }
        if (chat.receiver_name) {
          allUsers.add(chat.receiver_name);
        }
      });

      // Add users from reports
      reportsUsers.data?.forEach(report => {
        if (report.guest_name) {
          allUsers.add(report.guest_name);
        }
      });

      const suggestions = Array.from(allUsers)
        .slice(0, 10)
        .map(user => ({ username: user, last_seen: 'Recently active' }));

      setUserSuggestions(suggestions);
    } catch (error) {
      console.error('Error fetching user suggestions:', error);
    }
  };

  const removeSuggestion = (username: string) => {
    setUserSuggestions(prev => prev.filter(suggestion => suggestion.username !== username));
    toast.success("Suggestion removed");
  };

  const fetchAllData = async () => {
    try {
      const [reportsRes, publicRes, privateRes, adminRes, postsRes] = await Promise.all([
        supabase.from('reports').select('*').order('timestamp', { ascending: false }),
        supabase.from('public_chat').select('*').order('timestamp', { ascending: false }),
        supabase.from('private_chats').select('*').order('timestamp', { ascending: false }),
        supabase.from('admin_messages').select('*').order('timestamp', { ascending: false }),
        supabase.from('posts').select('*').order('timestamp', { ascending: false })
      ]);

      if (reportsRes.error) console.error('Reports error:', reportsRes.error);
      else setReports(reportsRes.data || []);

      if (publicRes.error) console.error('Public chat error:', publicRes.error);
      else setPublicMessages(publicRes.data || []);

      if (privateRes.error) console.error('Private chat error:', privateRes.error);
      else setPrivateMessages(privateRes.data || []);

      if (adminRes.error) console.error('Admin messages error:', adminRes.error);
      else setAdminMessages(adminRes.data || []);

      if (postsRes.error) console.error('Posts error:', postsRes.error);
      else setPosts(postsRes.data || []);

    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error("Failed to load admin data");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRespondToReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReport || !adminResponse.trim()) return;

    try {
      const { error } = await supabase
        .from('reports')
        .update({
          admin_response: adminResponse.trim(),
          admin_response_timestamp: new Date().toISOString()
        })
        .eq('id', selectedReport.id);

      if (error) {
        console.error('Error updating report:', error);
        toast.error("Failed to update report");
        return;
      }

      toast.success("Report response saved");
      setAdminResponse('');
      fetchAllData();
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("An unexpected error occurred");
    }
  };

  const closeReport = async (reportId: string) => {
    if (!confirm('Are you sure you want to close this report?')) return;

    try {
      const { error } = await supabase
        .from('reports')
        .update({ status: 'closed' })
        .eq('id', reportId);

      if (error) {
        console.error('Error closing report:', error);
        toast.error("Failed to close report");
        return;
      }

      toast.success("Report closed");
      fetchAllData();
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("An unexpected error occurred");
    }
  };

  const deleteReport = async (reportId: string) => {
    if (!confirm('Are you sure you want to delete this report? This action cannot be undone.')) return;

    try {
      const { error } = await supabase
        .from('reports')
        .delete()
        .eq('id', reportId);

      if (error) {
        console.error('Error deleting report:', error);
        toast.error("Failed to delete report");
        return;
      }

      toast.success("Report deleted");
      if (selectedReport?.id === reportId) {
        setSelectedReport(null);
      }
      fetchAllData();
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("An unexpected error occurred");
    }
  };

  const deletePublicMessage = async (messageId: string) => {
    if (!confirm('Are you sure you want to delete this message?')) return;

    try {
      const { error } = await supabase
        .from('public_chat')
        .delete()
        .eq('id', messageId);

      if (error) {
        console.error('Error deleting message:', error);
        toast.error("Failed to delete message");
        return;
      }

      toast.success("Message deleted");
      fetchAllData();
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("An unexpected error occurred");
    }
  };

  const deletePrivateMessage = async (messageId: string) => {
    if (!confirm('Are you sure you want to delete this private message?')) return;

    try {
      const { error } = await supabase
        .from('private_chats')
        .delete()
        .eq('id', messageId);

      if (error) {
        console.error('Error deleting private message:', error);
        toast.error("Failed to delete private message");
        return;
      }

      toast.success("Private message deleted");
      fetchAllData();
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("An unexpected error occurred");
    }
  };

  const deletePost = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this post?')) return;

    try {
      const { error } = await supabase
        .from('posts')
        .delete()
        .eq('id', postId);

      if (error) {
        console.error('Error deleting post:', error);
        toast.error("Failed to delete post");
        return;
      }

      toast.success("Post deleted");
      fetchAllData();
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("An unexpected error occurred");
    }
  };

  const muteUser = async () => {
    if (!muteUsername.trim()) {
      toast.error("Please enter a username to mute");
      return;
    }

    try {
      const { error } = await supabase
        .from('muted_users')
        .insert({
          username: muteUsername.trim(),
          muted_by: 'admin',
          reason: muteReason.trim() || 'No reason provided'
        });

      if (error) {
        console.error('Error muting user:', error);
        toast.error("Failed to mute user");
        return;
      }

      toast.success(`User ${muteUsername} has been muted`);
      setMuteUsername('');
      setMuteReason('');
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("An unexpected error occurred");
    }
  };

  const sendAdminMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGuest || !newAdminMessage.trim()) return;

    try {
      const { error } = await supabase
        .from('admin_messages')
        .insert({
          guest_name: selectedGuest,
          message: newAdminMessage.trim(),
          sender_type: 'admin'
        });

      if (error) {
        console.error('Error sending admin message:', error);
        toast.error("Failed to send message");
        return;
      }

      // Also add to report replies if we have a selected report for this guest
      if (selectedReport && selectedReport.guest_name === selectedGuest) {
        setReportReplies(prev => [...prev, {
          id: Date.now().toString(),
          guest_name: selectedGuest,
          message: newAdminMessage.trim(),
          sender_type: 'admin',
          timestamp: new Date().toISOString()
        }]);
      }

      toast.success("Message sent to user");
      setNewAdminMessage('');
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error("An unexpected error occurred");
    }
  };

  const getUniqueGuests = () => {
    const guests = new Set<string>();
    adminMessages.forEach(msg => guests.add(msg.guest_name));
    reports.forEach(report => guests.add(report.guest_name));
    return Array.from(guests).sort();
  };

  const getGuestMessages = () => {
    if (!selectedGuest) return [];
    return adminMessages.filter(msg => msg.guest_name === selectedGuest);
  };

  const getPrivateChat = () => {
    if (!player1 || !player2) return [];
    return privateMessages.filter(msg => 
      (msg.sender_name === player1 && msg.receiver_name === player2) ||
      (msg.sender_name === player2 && msg.receiver_name === player1)
    ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  const handleCreateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!announcementTitle.trim() || !announcementContent.trim()) {
      toast.error('Title and content are required');
      return;
    }

    try {
      let imageUrl = '';
      
      if (announcementImage) {
        const fileName = `announcement-${Date.now()}-${announcementImage.name}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('post-images')
          .upload(fileName, announcementImage);

        if (uploadError) {
          console.error('Error uploading image:', uploadError);
          toast.error('Failed to upload image');
          return;
        }

        const { data: { publicUrl } } = supabase.storage
          .from('post-images')
          .getPublicUrl(fileName);
        
        imageUrl = publicUrl;
      }

      const { error } = await supabase
        .from('announcements')
        .insert({
          title: announcementTitle,
          content: announcementContent,
          image_url: imageUrl || null,
          author: 'Admin'
        });

      if (error) {
        console.error('Error creating announcement:', error);
        toast.error('Failed to create announcement');
        return;
      }

      toast.success('Announcement created successfully');
      setAnnouncementTitle('');
      setAnnouncementContent('');
      setAnnouncementImage(null);
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error('Failed to create announcement');
    }
  };

  const deleteAnnouncement = async (announcementId: string) => {
    try {
      const { error } = await supabase
        .from('announcements')
        .delete()
        .eq('id', announcementId);

      if (error) {
        console.error('Error deleting announcement:', error);
        toast.error('Failed to delete announcement');
        return;
      }

      toast.success('Announcement deleted');
    } catch (error) {
      console.error('Unexpected error:', error);
      toast.error('Failed to delete announcement');
    }
  };

  // Clear all public chat history
  const clearPublicChatHistory = async () => {
    if (!confirm('Are you sure you want to clear ALL public chat messages? This cannot be undone.')) return;
    try {
      const { error } = await supabase
        .from('public_chat')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');
      if (error) {
        console.error('Error clearing public chat:', error);
        toast.error('Failed to clear public chat');
        return;
      }
      toast.success('Public chat history cleared');
      fetchAllData();
    } catch (error) {
      console.error('Unexpected error clearing chat:', error);
      toast.error('Failed to clear public chat');
    }
  };

  // Toggle a user's role in user_badges table
  const toggleUserRole = async (userName: string, key: 'staff' | 'verified' | 'bot') => {
    try {
      const { data: existing, error: selError } = await supabase
        .from('user_badges')
        .select('*')
        .eq('user_name', userName)
        .maybeSingle();

      if (selError) {
        console.error('Select role error:', selError);
      }

      if (existing) {
        const newValue = !(existing as any)[key];
        const { error: updError } = await supabase
          .from('user_badges')
          .update({ [key]: newValue })
          .eq('id', (existing as any).id);
        if (updError) throw updError;
        toast.success(`${key} ${newValue ? 'enabled' : 'disabled'} for ${userName}`);
      } else {
        const insertPayload: any = { user_name: userName, staff: false, verified: false, bot: false };
        insertPayload[key] = true;
        const { error: insError } = await supabase
          .from('user_badges')
          .insert(insertPayload);
        if (insError) throw insError;
        toast.success(`${key} enabled for ${userName}`);
      }
    } catch (error) {
      console.error('Role toggle error:', error);
      toast.error('Failed to toggle role');
    }
  };

  // Fetch inactive users (inactive for 24+ hours)
  const fetchInactiveUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('username, last_active, created_at')
        .lt('last_active', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
        .order('last_active', { ascending: false });

      if (error) {
        console.error('Error fetching inactive users:', error);
        return;
      }

      setInactiveUsers(data || []);
    } catch (error) {
      console.error('Unexpected error fetching inactive users:', error);
    }
  };

  // Delete account and all associated data
  const deleteUserAccount = async () => {
    if (!deleteAccountUsername.trim()) {
      toast.error("Please enter a username");
      return;
    }

    if (!confirm(`Are you sure you want to delete ${deleteAccountUsername} and ALL their data? This cannot be undone.`)) {
      return;
    }

    try {
      // Delete in order to respect foreign key constraints
      const username = deleteAccountUsername.trim();
      
      // Delete from all tables that reference the user
      await Promise.all([
        supabase.from('posts').delete().eq('author_name', username),
        supabase.from('post_likes').delete().eq('user_name', username),
        supabase.from('post_dislikes').delete().eq('user_name', username),
        supabase.from('public_chat').delete().eq('sender_name', username),
        supabase.from('private_chats').delete().or(`sender_name.eq.${username},receiver_name.eq.${username}`),
        supabase.from('admin_messages').delete().eq('guest_name', username),
        supabase.from('reports').delete().eq('guest_name', username),
        supabase.from('friends').delete().or(`user1.eq.${username},user2.eq.${username}`),
        supabase.from('notifications').delete().or(`from_user.eq.${username},to_user.eq.${username}`),
        supabase.from('muted_users').delete().eq('username', username),
        supabase.from('user_badges').delete().eq('user_name', username),
        supabase.from('active_chats').delete().or(`user1.eq.${username},user2.eq.${username}`)
      ]);

      // Finally delete the profile
      const { error: profileError } = await supabase
        .from('profiles')
        .delete()
        .eq('username', username);

      if (profileError) {
        console.error('Error deleting profile:', profileError);
        toast.error("Failed to delete user profile");
        return;
      }

      toast.success(`Account ${username} and all associated data has been deleted`);
      setDeleteAccountUsername('');
      fetchAllData(); // Refresh all data
    } catch (error) {
      console.error('Error deleting user account:', error);
      toast.error("Failed to delete user account");
    }
  };

  // Admin access control function
  const toggleAdminAccess = async () => {
    if (!adminAccessUsername.trim()) {
      toast.error("Please enter a username");
      return;
    }

    const username = adminAccessUsername.trim();
    const enableAccess = adminAccessAction === 'enable';

    try {
      // Check if user badge entry exists
      const { data: existingBadge } = await supabase
        .from('user_badges')
        .select('*')
        .eq('user_name', username)
        .maybeSingle();

      if (existingBadge) {
        // Update existing badge
        const { error } = await supabase
          .from('user_badges')
          .update({ staff: enableAccess })
          .eq('user_name', username);

        if (error) throw error;
      } else {
        // Create new badge entry
        const { error } = await supabase
          .from('user_badges')
          .insert({
            user_name: username,
            staff: enableAccess,
            verified: false,
            bot: false
          });

        if (error) throw error;
      }

      toast.success(`Admin access ${enableAccess ? 'enabled' : 'disabled'} for ${username}`);
      setAdminAccessUsername('');
      fetchUserSuggestions(); // Refresh suggestions
    } catch (error) {
      console.error('Error toggling admin access:', error);
      toast.error("Failed to update admin access");
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 pb-20">
        <Card>
          <CardContent className="p-6">
            <div className="text-center">Loading admin panel...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 pb-20">
      <Card className="shadow-xl border-0 bg-gradient-to-r from-blue-50 to-purple-50">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
          <CardTitle className="text-center text-3xl font-bold">Admin Control Panel</CardTitle>
          <p className="text-center text-blue-100">
            Manage reports, messages, users, and announcements
          </p>
        </CardHeader>
        <CardContent className="p-8">
          {/* Main Action Buttons Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Button 
              onClick={() => setSelectedTab("reports")}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white border-0 shadow-lg"
            >
              <Trash2 className="w-6 h-6" />
              <span className="font-semibold">Manage Reports</span>
            </Button>
            
            <Button 
              onClick={() => setSelectedTab("messages")}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white border-0 shadow-lg"
            >
              <MessageCircle className="w-6 h-6" />
              <span className="font-semibold">Public Messages</span>
            </Button>
            
            <Button 
              onClick={() => setSelectedTab("private")}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white border-0 shadow-lg"
            >
              <Users className="w-6 h-6" />
              <span className="font-semibold">Private Chats</span>
            </Button>
            
            <Button 
              onClick={() => setSelectedTab("admin-messages")}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white border-0 shadow-lg"
            >
              <Send className="w-6 h-6" />
              <span className="font-semibold">Admin Chat</span>
            </Button>
            
            <Button 
              onClick={() => setSelectedTab("posts")}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white border-0 shadow-lg"
            >
              <Archive className="w-6 h-6" />
              <span className="font-semibold">Manage Posts</span>
            </Button>
            
            <Button 
              onClick={() => setSelectedTab("announcements")}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-pink-500 to-pink-600 hover:from-pink-600 hover:to-pink-700 text-white border-0 shadow-lg"
            >
              <Megaphone className="w-6 h-6" />
              <span className="font-semibold">Announcements</span>
            </Button>
            
            <Button 
              onClick={() => setSelectedTab("tutorials")}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white border-0 shadow-lg"
            >
              <Plus className="w-6 h-6" />
              <span className="font-semibold">Tutorials</span>
            </Button>
            
            <Button 
              onClick={() => { 
                setSelectedTab("admin-access");
                setTimeout(() => {
                  const element = document.getElementById('admin-admin-access');
                  if (element) element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 100);
              }}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white border-0 shadow-lg"
            >
              <Users className="w-6 h-6" />
              <span className="font-semibold">Admin Access</span>
            </Button>

            <Button 
              onClick={() => setSelectedTab("mute")}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700 text-white border-0 shadow-lg"
            >
              <UserX className="w-6 h-6" />
              <span className="font-semibold">Mute Users</span>
            </Button>
            
            <Button 
              onClick={() => { 
                setSelectedTab("inactive-users");
                fetchInactiveUsers(); // Auto-fetch when clicking
                setTimeout(() => {
                  const element = document.getElementById('admin-inactive-users');
                  if (element) element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 100);
              }}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white border-0 shadow-lg"
            >
              <Users className="w-6 h-6" />
              <span className="font-semibold">Inactive Users</span>
            </Button>
            
            <Button 
              onClick={() => { 
                setSelectedTab("user-roles");
                setTimeout(() => {
                  const element = document.getElementById('admin-user-roles');
                  if (element) element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 100);
              }}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white border-0 shadow-lg"
            >
              <CheckCircle className="w-6 h-6" />
              <span className="font-semibold">User Roles</span>
            </Button>
            
            <Button 
              onClick={() => { 
                setSelectedTab("delete-accounts");
                setTimeout(() => {
                  const element = document.getElementById('admin-delete-accounts');
                  if (element) element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 100);
              }}
              className="h-20 flex flex-col gap-2 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white border-0 shadow-lg"
            >
              <Trash2 className="w-6 h-6" />
              <span className="font-semibold">Delete Accounts</span>
            </Button>
          </div>

          {/* Content Area */}
          <div className="bg-white rounded-lg p-6 shadow-lg border">
            {selectedTab === "announcements" && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Create New Announcement</h3>
                <form onSubmit={handleCreateAnnouncement} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Announcement Title
                    </label>
                    <Input
                      value={announcementTitle}
                      onChange={(e) => setAnnouncementTitle(e.target.value)}
                      placeholder="Enter announcement title"
                      required
                      className="w-full"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Content
                    </label>
                    <Textarea
                      value={announcementContent}
                      onChange={(e) => setAnnouncementContent(e.target.value)}
                      placeholder="Enter announcement content"
                      required
                      className="w-full min-h-[120px]"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Image (Optional)
                    </label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setAnnouncementImage(e.target.files?.[0] || null)}
                      className="w-full"
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
                  >
                    <Megaphone className="w-4 h-4 mr-2" />
                    Create Announcement
                  </Button>
                </form>
              </div>
            )}

            {selectedTab === "mute" && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Mute User</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Username to Mute
                    </label>
                    <Input
                      value={muteUsername}
                      onChange={(e) => setMuteUsername(e.target.value)}
                      placeholder="Enter username"
                      className="w-full"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Reason (Optional)
                    </label>
                    <Textarea
                      value={muteReason}
                      onChange={(e) => setMuteReason(e.target.value)}
                      placeholder="Enter reason for muting"
                      className="w-full"
                    />
                  </div>
                  
                  <Button 
                    onClick={muteUser}
                    className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white"
                  >
                    <UserX className="w-4 h-4 mr-2" />
                    Mute User
                  </Button>
                </div>
              </div>
            )}

            {selectedTab === "admin-access" && (
              <div id="admin-admin-access" className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Admin Panel Access Control</h3>
                
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Admin Access Management</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                        <h4 className="font-semibold text-amber-800 mb-2">Access Levels</h4>
                        <div className="space-y-2 text-sm text-amber-700">
                          <div className="flex items-center gap-2">
                            <Badge className="bg-blue-600 text-white">Full Admin</Badge>
                            <span>Complete admin panel access (Simson_Rodger level)</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className="bg-green-600 text-white">Creator</Badge>
                            <span>Limited to tutorials management only</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className="bg-gray-600 text-white">Disabled</Badge>
                            <span>No admin panel access</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex flex-col sm:flex-row gap-4">
                        <Input
                          value={adminAccessUsername}
                          onChange={(e) => setAdminAccessUsername(e.target.value)}
                          placeholder="Enter username"
                          className="flex-1"
                        />
                        <Select value={adminAccessAction} onValueChange={(value) => setAdminAccessAction(value as 'enable' | 'disable')}>
                          <SelectTrigger className="w-full sm:w-40">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="enable">Enable Access</SelectItem>
                            <SelectItem value="disable">Disable Access</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          onClick={toggleAdminAccess}
                          className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto"
                          disabled={!adminAccessUsername.trim()}
                        >
                          {adminAccessAction === 'enable' ? 'Enable' : 'Disable'} Access
                        </Button>
                      </div>
                      <p className="text-sm text-gray-600">
                        Control admin panel access. Creators get limited access (tutorials only), full admins get complete access.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {selectedTab === "inactive-users" && (
              <div id="admin-inactive-users" className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-bold text-gray-900">Inactive Users (24+ hours)</h3>
                  <Button 
                    onClick={fetchInactiveUsers}
                    variant="outline"
                    className="flex items-center gap-2"
                  >
                    <Users className="w-4 h-4" />
                    Refresh List
                  </Button>
                </div>
                
                <div className="grid gap-4 max-h-96 overflow-y-auto">
                  {inactiveUsers.length === 0 ? (
                    <Card>
                      <CardContent className="p-6 text-center">
                        <Users className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                        <p className="text-gray-600">No inactive users found or list not loaded yet.</p>
                        <p className="text-sm text-gray-500 mt-2">Click "Refresh List" to load inactive users.</p>
                      </CardContent>
                    </Card>
                  ) : (
                    inactiveUsers.map((user, index) => (
                      <Card key={index} className="border-l-4 border-l-yellow-500">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold text-gray-900">{user.username}</h4>
                              <p className="text-sm text-gray-600">
                                Last active: {new Date(user.last_active).toLocaleString()}
                              </p>
                              <p className="text-xs text-gray-500">
                                Account created: {new Date(user.created_at).toLocaleString()}
                              </p>
                            </div>
                            <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                              Inactive
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </div>
            )}

            {selectedTab === "delete-accounts" && (
              <div id="admin-delete-accounts" className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Delete User Account</h3>
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                  <div className="flex items-center">
                    <Trash2 className="w-5 h-5 text-red-600 mr-2" />
                    <h4 className="font-semibold text-red-800">⚠️ Warning: Permanent Deletion</h4>
                  </div>
                  <p className="text-red-700 mt-2 text-sm">
                    This will permanently delete the user and ALL associated data including:
                    posts, messages, reports, friendships, notifications, and profile information.
                    This action cannot be undone.
                  </p>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Username to Delete
                    </label>
                    <Input
                      value={deleteAccountUsername}
                      onChange={(e) => setDeleteAccountUsername(e.target.value)}
                      placeholder="Enter username to delete"
                      className="w-full"
                    />
                  </div>
                  
                  <Button 
                    onClick={deleteUserAccount}
                    className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white"
                    disabled={!deleteAccountUsername.trim()}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete Account & All Data
                  </Button>
                </div>
              </div>
            )}

            {selectedTab === "user-roles" && (
              <div id="admin-user-roles" className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">User Roles & Badges Management</h3>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Assign Roles & Badges to Users</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 className="font-semibold text-blue-800 mb-2">Current Staff Member</h4>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-blue-600 text-white">Staff</Badge>
                          <span className="font-semibold">Simson_Rodger</span>
                        </div>
                        <p className="text-sm text-blue-700 mt-1">Current active admin panel user</p>
                      </div>
                      
                      {userSuggestions.length === 0 ? (
                        <div className="text-center py-8">
                          <Users className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                          <p className="text-gray-600">No users found to assign roles</p>
                          <p className="text-sm text-gray-500 mt-2">Users will appear here once they start using the platform</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {userSuggestions.map((u) => (
                            <div key={u.username} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border rounded-lg gap-3">
                              <div>
                                <p className="font-semibold">{u.username}</p>
                                <p className="text-xs text-gray-500">{u.last_seen}</p>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => toggleUserRole(u.username, 'staff')}
                                  className="text-xs"
                                >
                                  Toggle Staff
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => toggleUserRole(u.username, 'verified')}
                                  className="text-xs"
                                >
                                  Toggle Verified ✓
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => toggleUserRole(u.username, 'bot')}
                                  className="text-xs"
                                >
                                  Toggle Bot
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

          <Tabs value={selectedTab} onValueChange={(value) => {
            setSelectedTab(value);
            // Auto scroll to content on mobile
            setTimeout(() => {
              const element = document.getElementById(`admin-${value}`);
              if (element) {
                element.scrollIntoView({ behavior: 'smooth', block: 'start' });
              }
            }, 100);
          }} className="w-full">
            <TabsList className="hidden">
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="messages">Messages</TabsTrigger>
              <TabsTrigger value="private">Private Chats</TabsTrigger>
              <TabsTrigger value="admin-messages">Admin Chat</TabsTrigger>
              <TabsTrigger value="posts">Posts</TabsTrigger>
              <TabsTrigger value="tutorials">Tutorials</TabsTrigger>
              <TabsTrigger value="announcements">Announcements</TabsTrigger>
              <TabsTrigger value="roles">Users & Roles</TabsTrigger>
              <TabsTrigger value="mute">Mute</TabsTrigger>
              <TabsTrigger value="inactive-users">Inactive Users</TabsTrigger>
              <TabsTrigger value="delete-accounts">Delete Accounts</TabsTrigger>
            </TabsList>

            <TabsContent value="reports" className="space-y-4">
              <h3 className="text-xl font-semibold">Reports Management</h3>
              <div className="grid grid-cols-1 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>All Reports ({reports.length})</span>
                      <Badge variant="secondary">{reports.filter(r => !r.admin_response).length} pending</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {reports.map((report) => (
                        <div
                          key={report.id}
                          className={`p-3 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                            selectedReport?.id === report.id ? 'bg-muted border-primary' : ''
                          }`}
                          onClick={() => { setSelectedReport(report); setReportDialogOpen(true); }}
                        >
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge variant="outline" className="text-xs">{report.type}</Badge>
                                <span className="text-xs text-muted-foreground">
                                  by {report.guest_name}
                                </span>
                              </div>
                              <div className="flex gap-1 flex-wrap">
                                {report.admin_response && (
                                  <Badge className="bg-green-100 text-green-800 text-xs px-2 py-1">Responded</Badge>
                                )}
                                {report.status === 'closed' && (
                                  <Badge className="bg-gray-100 text-gray-800 text-xs px-2 py-1">Closed</Badge>
                                )}
                              </div>
                            </div>
                            <p className="text-sm line-clamp-2 break-words">{report.description}</p>
                            <div className="flex justify-between items-center flex-wrap gap-2">
                              <p className="text-xs text-muted-foreground">
                                {formatTime(report.timestamp)}
                              </p>
                              <div className="flex gap-1">
                                <Button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    closeReport(report.id);
                                  }}
                                  variant="outline"
                                  size="sm"
                                  className="text-xs px-2 py-1 h-auto"
                                >
                                  <CheckCircle className="w-3 h-3 mr-1" />
                                  <span className="hidden sm:inline">Close</span>
                                </Button>
                                <Button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    deleteReport(report.id);
                                  }}
                                  variant="outline"
                                  size="sm"
                                  className="text-xs px-2 py-1 h-auto text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="w-3 h-3 mr-1" />
                                  <span className="hidden sm:inline">Delete</span>
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

<Dialog open={reportDialogOpen} onOpenChange={(open) => { setReportDialogOpen(open); if (!open) setSelectedReport(null); }}>
  <DialogContent className="max-w-2xl">
    <DialogHeader>
      <DialogTitle>Report Details & Conversation</DialogTitle>
    </DialogHeader>
    {selectedReport && (
      <div className="space-y-4">
        <div>
          <strong>Type:</strong> {selectedReport.type}
        </div>
        <div>
          <strong>Guest:</strong> {selectedReport.guest_name}
        </div>
        <div>
          <strong>Description:</strong>
          <p className="mt-1 text-sm bg-muted p-2 rounded">
            {selectedReport.description}
          </p>
        </div>
        {selectedReport.screenshot_url && (
          <div>
            <strong>Screenshot:</strong>
            <img 
              src={selectedReport.screenshot_url} 
              alt="Report screenshot" 
              className="mt-1 max-w-full h-auto rounded border"
            />
          </div>
        )}
        <div>
          <strong>Submitted:</strong> {formatTime(selectedReport.timestamp)}
        </div>

        <div className="border-t pt-4">
          <strong className="block mb-3">Conversation:</strong>
          <div className="h-64 overflow-y-auto border rounded p-4 bg-muted/50 space-y-3">
            {reportReplies.length === 0 ? (
              <p className="text-muted-foreground text-center">No conversation yet</p>
            ) : (
              reportReplies.map((reply) => (
                <div key={reply.id} className={`flex ${reply.sender_type === 'admin' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs lg:max-w-md px-3 py-2 rounded-lg ${
                    reply.sender_type === 'admin' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-blue-100 text-blue-900 border'
                  }`}>
                    <div className="flex items-baseline gap-2 mb-1">
                      <span className="font-semibold text-xs">
                        {reply.sender_type === 'admin' ? 'Admin' : reply.guest_name}
                      </span>
                      <span className="text-xs opacity-70">
                        {formatTime(reply.timestamp)}
                      </span>
                    </div>
                    <div className="text-sm">{reply.message}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <form onSubmit={handleRespondToReport} className="space-y-4 border-t pt-4">
          <Textarea
            value={adminResponse}
            onChange={(e) => setAdminResponse(e.target.value)}
            placeholder="Type your response..."
            rows={4}
          />
          <div className="flex flex-col gap-2">
            <Button type="submit" className="w-full">
              <Send className="w-4 h-4 mr-2" />
              Send Response
            </Button>
            <div className="flex gap-2">
              <Button
                type="button"
                onClick={() => closeReport(selectedReport.id)}
                variant="outline"
                className="flex-1 text-blue-600 hover:text-blue-700"
              >
                <CheckCircle className="w-4 h-4 mr-1" />
                Close Report
              </Button>
              <Button
                type="button"
                onClick={() => deleteReport(selectedReport.id)}
                variant="outline"
                className="flex-1 text-red-600 hover:text-red-700"
              >
                <Trash2 className="w-4 h-4 mr-1" />
                Delete Report
              </Button>
            </div>
          </div>
        </form>
      </div>
    )}
  </DialogContent>
</Dialog>
              </div>
            </TabsContent>

            <TabsContent value="messages">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between gap-2">
                    <span>Public Chat History ({publicMessages.length} messages)</span>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">Admin Mode</Badge>
                      <Button onClick={clearPublicChatHistory} variant="destructive" size="sm">
                        <Trash2 className="w-4 h-4 mr-1" /> Clear History
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-96 overflow-y-auto border rounded p-4 bg-muted/50">
                    {publicMessages.map((msg) => (
                      <div key={msg.id} className="mb-3 group flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-baseline gap-2">
                            <span className="font-semibold text-primary">{msg.sender_name}</span>
                            <span className="text-xs text-muted-foreground">
                              {formatTime(msg.timestamp)}
                            </span>
                          </div>
                          <div className="text-sm mt-1">{msg.message}</div>
                        </div>
                        <Button
                          onClick={() => deletePublicMessage(msg.id)}
                          variant="ghost"
                          size="sm"
                          className="opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:text-red-600 ml-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="private">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Private Chat History ({privateMessages.length} messages)</span>
                    <Badge variant="secondary">Admin Mode</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-96 overflow-y-auto border rounded p-4 bg-muted/50">
                    {privateMessages.map((msg) => (
                      <div key={msg.id} className="mb-3 group flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-baseline gap-2">
                            <span className="font-semibold text-purple-600">{msg.sender_name}</span>
                            <span className="text-xs text-gray-400">→</span>
                            <span className="font-semibold text-blue-600">{msg.receiver_name}</span>
                            <span className="text-xs text-muted-foreground">
                              {formatTime(msg.timestamp)}
                            </span>
                          </div>
                          <div className="text-sm mt-1">{msg.message}</div>
                        </div>
                        <Button
                          onClick={() => deletePrivateMessage(msg.id)}
                          variant="ghost"
                          size="sm"
                          className="opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:text-red-600 ml-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="posts">
              <Card>
                <CardHeader>
                  <CardTitle>Community Posts ({posts.length} posts)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {posts.map((post) => (
                      <div key={post.id} className="border rounded-lg p-4 group">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-semibold">{post.title}</h3>
                            <p className="text-sm text-muted-foreground">
                              by {post.author_name} • {formatTime(post.timestamp)} • {post.likes} likes
                            </p>
                          </div>
                          <Button
                            onClick={() => deletePost(post.id)}
                            variant="ghost"
                            size="sm"
                            className="opacity-0 group-hover:opacity-100 transition-opacity text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                        <p className="text-sm text-gray-600 line-clamp-3">{post.content}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="moderation">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <UserX className="w-5 h-5" />
                      User Moderation
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Input
                        placeholder="Username to mute"
                        value={muteUsername}
                        onChange={(e) => setMuteUsername(e.target.value)}
                      />
                      <Input
                        placeholder="Reason (optional)"
                        value={muteReason}
                        onChange={(e) => setMuteReason(e.target.value)}
                      />
                    </div>
                    <Button onClick={muteUser} className="w-full">
                      <UserX className="w-4 h-4 mr-2" />
                      Mute User from Public Chat
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>User Suggestions ({userSuggestions.length})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {userSuggestions.length === 0 ? (
                        <p className="text-muted-foreground text-center py-4">
                          No user suggestions available
                        </p>
                      ) : (
                        userSuggestions.map((user) => (
                          <div key={user.username} className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <p className="font-semibold">{user.username}</p>
                              <p className="text-xs text-gray-500">{user.last_seen}</p>
                            </div>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => removeSuggestion(user.username)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        ))
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="tutorials">
              <TutorialManager />
            </TabsContent>

            <TabsContent value="roles">
              <Card>
                <CardHeader>
                  <CardTitle>Assign Roles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {userSuggestions.length === 0 ? (
                      <p className="text-muted-foreground text-center py-4">No users found</p>
                    ) : (
                      userSuggestions.map((u) => (
                        <div key={u.username} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-semibold">{u.username}</p>
                            <p className="text-xs text-gray-500">{u.last_seen}</p>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => toggleUserRole(u.username, 'staff')}>Toggle Staff</Button>
                            <Button size="sm" variant="outline" onClick={() => toggleUserRole(u.username, 'verified')}>Toggle Verified</Button>
                            <Button size="sm" variant="outline" onClick={() => toggleUserRole(u.username, 'bot')}>Toggle Bot</Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="messages">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Megaphone className="w-5 h-5" />
                      Send Message to User
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Select value={selectedGuest} onValueChange={setSelectedGuest}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a user to message" />
                      </SelectTrigger>
                      <SelectContent>
                        {getUniqueGuests().map((guest) => (
                          <SelectItem key={guest} value={guest}>
                            {guest}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>

                {selectedGuest && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Messages with {selectedGuest}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="h-64 overflow-y-auto border rounded p-4 bg-muted/50">
                        {getGuestMessages().map((msg) => (
                          <div key={msg.id} className={`mb-3 ${msg.sender_type === 'admin' ? 'text-right' : 'text-left'}`}>
                            <div className={`inline-block max-w-xs lg:max-w-md px-3 py-2 rounded-lg ${
                              msg.sender_type === 'admin' 
                                ? 'bg-primary text-primary-foreground' 
                                : 'bg-muted border'
                            }`}>
                              <div className="flex items-baseline gap-2 mb-1">
                                <span className="font-semibold text-xs">
                                  {msg.sender_type === 'admin' ? 'Admin' : msg.guest_name}
                                </span>
                                <span className="text-xs opacity-70">
                                  {formatTime(msg.timestamp)}
                                </span>
                              </div>
                              <div className="text-sm">{msg.message}</div>
                            </div>
                          </div>
                        ))}
                      </div>

                      <form onSubmit={sendAdminMessage} className="space-y-4">
                        <Textarea
                          value={newAdminMessage}
                          onChange={(e) => setNewAdminMessage(e.target.value)}
                          placeholder="Type your message to the user..."
                          rows={3}
                        />
                        <Button type="submit" className="w-full">
                          Send Message
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>
          </Tabs>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminPanel;
